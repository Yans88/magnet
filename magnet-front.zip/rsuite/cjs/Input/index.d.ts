import Input from './Input';
export type { InputProps } from './Input';
export default Input;
