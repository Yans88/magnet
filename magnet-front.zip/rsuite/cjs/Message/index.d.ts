import Message from './Message';
export type { MessageProps } from './Message';
export default Message;
