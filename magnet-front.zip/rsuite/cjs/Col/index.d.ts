import Col from './Col';
export type { ColProps } from './Col';
export default Col;
