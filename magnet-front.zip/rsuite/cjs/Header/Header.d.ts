import { ComponentProps } from '../utils/createComponent';
export declare type HeaderProps = ComponentProps;
declare const Header: import("../@types/common").RsRefForwardingComponent<"div", ComponentProps>;
export default Header;
