declare const isElement: (node: HTMLElement) => boolean;
export default isElement;
