import Uploader from './Uploader';
export type { UploaderProps, FileStatusType, FileType } from './Uploader';
export default Uploader;
