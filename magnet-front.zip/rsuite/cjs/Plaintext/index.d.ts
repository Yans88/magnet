import Plaintext from './Plaintext';
export type { PlaintextProps } from './Plaintext';
export default Plaintext;
