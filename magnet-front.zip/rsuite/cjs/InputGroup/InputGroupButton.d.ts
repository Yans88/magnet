import React from 'react';
import { ButtonProps } from '../Button';
declare const InputGroupButton: React.ForwardRefExoticComponent<ButtonProps & React.RefAttributes<any>>;
export default InputGroupButton;
