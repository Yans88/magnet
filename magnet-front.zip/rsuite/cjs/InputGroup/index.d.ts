import InputGroup from './InputGroup';
export type { InputGroupProps } from './InputGroup';
export default InputGroup;
