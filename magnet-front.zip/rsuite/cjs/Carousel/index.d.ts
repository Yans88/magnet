import Carousel from './Carousel';
export type { CarouselProps } from './Carousel';
export default Carousel;
