import AvatarGroup from './AvatarGroup';
export type { AvatarGroupProps } from './AvatarGroup';
export default AvatarGroup;
