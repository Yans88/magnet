import Overlay from './Overlay';
export type { OverlayProps } from './Overlay';
export default Overlay;
