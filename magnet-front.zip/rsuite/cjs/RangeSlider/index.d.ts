import RangeSlider from './RangeSlider';
export type { RangeSliderProps } from './RangeSlider';
export default RangeSlider;
