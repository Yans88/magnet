import Avatar from './Avatar';
export type { AvatarProps } from './Avatar';
export default Avatar;
