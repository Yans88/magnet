import { ComponentProps } from '../utils/createComponent';
export declare type SidenavHeaderProps = ComponentProps;
declare const SidenavHeader: import("../@types/common").RsRefForwardingComponent<"div", ComponentProps>;
export default SidenavHeader;
