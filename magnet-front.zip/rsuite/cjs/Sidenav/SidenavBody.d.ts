import { ComponentProps } from '../utils/createComponent';
export declare type SidenavBodyProps = ComponentProps;
declare const SidenavBody: import("../@types/common").RsRefForwardingComponent<"div", ComponentProps>;
export default SidenavBody;
