import MultiCascader from './MultiCascader';
export type { MultiCascaderProps } from './MultiCascader';
export default MultiCascader;
