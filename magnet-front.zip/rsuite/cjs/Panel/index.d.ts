import Panel from './Panel';
export type { PanelProps } from './Panel';
export default Panel;
