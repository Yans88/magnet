import Rate from './Rate';
export type { RateProps } from './Rate';
export default Rate;
