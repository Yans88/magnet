import Tag from './Tag';
export type { TagProps } from './Tag';
export default Tag;
