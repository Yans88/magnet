import Table from './Table';
export type { TableProps, ColumnProps, ColumnGroupProps, TableLocaleType } from 'rsuite-table';
export type { TableInstance, CellProps } from './Table';
export default Table;
