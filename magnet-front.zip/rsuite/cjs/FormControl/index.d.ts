import FormControl from './FormControl';
export type { FormControlProps, FormControlAccepterProps } from './FormControl';
export default FormControl;
