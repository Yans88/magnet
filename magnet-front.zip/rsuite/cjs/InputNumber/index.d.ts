import InputNumber from './InputNumber';
export type { InputNumberProps } from './InputNumber';
export default InputNumber;
