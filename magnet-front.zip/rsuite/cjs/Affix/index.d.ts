import Affix from './Affix';
import type { AffixProps } from './Affix';
export type { AffixProps };
export default Affix;
