import IconButton from './IconButton';
export type { IconButtonProps } from './IconButton';
export default IconButton;
