import Slider from './Slider';
export type { SliderProps } from './Slider';
export default Slider;
