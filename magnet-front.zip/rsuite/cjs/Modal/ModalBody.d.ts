import { WithAsProps, RsRefForwardingComponent } from '../@types/common';
export declare type ModalBodyProps = WithAsProps;
declare const ModalBody: RsRefForwardingComponent<'div', ModalBodyProps>;
export default ModalBody;
