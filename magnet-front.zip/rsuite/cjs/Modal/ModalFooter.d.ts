import { ComponentProps } from '../utils/createComponent';
export declare type ModalFooterProps = ComponentProps;
declare const ModalFooter: import("../@types/common").RsRefForwardingComponent<"div", ComponentProps>;
export default ModalFooter;
