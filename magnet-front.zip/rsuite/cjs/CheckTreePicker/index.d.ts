import CheckTreePicker from './CheckTreePicker';
export type { CheckTreePickerProps, ValueType } from './CheckTreePicker';
export default CheckTreePicker;
