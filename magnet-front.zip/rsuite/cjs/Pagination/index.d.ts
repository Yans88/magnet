import PaginationGroup from './PaginationGroup';
export type { PaginationGroupProps as PaginationProps } from './PaginationGroup';
export type { PaginationProps as BasePaginationProps } from './Pagination';
export type { PaginationButtonProps } from './PaginationButton';
export default PaginationGroup;
