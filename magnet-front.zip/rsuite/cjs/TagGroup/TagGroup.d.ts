import { ComponentProps } from '../utils/createComponent';
export declare type TagGroupProps = ComponentProps;
declare const TagGroup: import("../@types/common").RsRefForwardingComponent<"div", ComponentProps>;
export default TagGroup;
