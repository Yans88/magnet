import MaskedInput from './MaskedInput';
export type { MaskedInputProps } from './MaskedInput';
export default MaskedInput;
