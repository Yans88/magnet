export interface ConfigType {
    guide?: boolean;
    previousConformedValue?: string;
    placeholderChar?: string;
    placeholder?: string;
    currentCaretPosition?: number;
    keepCharPositions?: boolean;
}
export declare type MaskType = string | (string | RegExp)[];
export declare type MaskFunctionType = (rawValue: string, config: ConfigType) => MaskType;
