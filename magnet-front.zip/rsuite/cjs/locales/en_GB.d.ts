import defaultObject from './default';
export default defaultObject;
