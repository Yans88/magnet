import FormControlLabel from './FormControlLabel';
export type { FormControlLabelProps } from './FormControlLabel';
export default FormControlLabel;
