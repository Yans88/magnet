import Divider from './Divider';
export type { DividerProps } from './Divider';
export default Divider;
