import { RsRefForwardingComponent, WithAsProps } from '../@types/common';
export declare type TableHeaderRowProps = WithAsProps;
declare const TableHeaderRow: RsRefForwardingComponent<'div', TableHeaderRowProps>;
export default TableHeaderRow;
