import { RsRefForwardingComponent, WithAsProps } from '../@types/common';
export declare type ViewProps = WithAsProps;
declare const View: RsRefForwardingComponent<'div', ViewProps>;
export default View;
