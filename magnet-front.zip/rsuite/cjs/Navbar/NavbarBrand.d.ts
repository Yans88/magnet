import { ComponentProps } from '../utils/createComponent';
export declare type NavbarBrandProps = ComponentProps;
declare const NavbarBrand: import("../@types/common").RsRefForwardingComponent<"div", ComponentProps>;
export default NavbarBrand;
