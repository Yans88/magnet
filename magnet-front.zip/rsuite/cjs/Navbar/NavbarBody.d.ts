import { ComponentProps } from '../utils/createComponent';
export declare type NavbarBodyProps = ComponentProps;
declare const _default: import("../@types/common").RsRefForwardingComponent<"div", ComponentProps>;
export default _default;
