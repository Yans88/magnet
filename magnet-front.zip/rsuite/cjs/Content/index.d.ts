import Content from './Content';
export type { ContentProps } from './Content';
export default Content;
