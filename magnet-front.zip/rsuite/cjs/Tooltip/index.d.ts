import Tooltip from './Tooltip';
export type { TooltipProps } from './Tooltip';
export default Tooltip;
