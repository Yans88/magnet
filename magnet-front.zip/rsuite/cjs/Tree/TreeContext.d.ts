import React from 'react';
export interface TreeContextProps {
    inline?: boolean;
}
declare const TreeContext: React.Context<TreeContextProps>;
export default TreeContext;
