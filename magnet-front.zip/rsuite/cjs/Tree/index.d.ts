import Tree from './Tree';
export type { TreeProps } from './Tree';
export default Tree;
