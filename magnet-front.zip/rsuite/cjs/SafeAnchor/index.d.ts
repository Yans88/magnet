import SafeAnchor from './SafeAnchor';
export type { SafeAnchorProps } from './SafeAnchor';
export default SafeAnchor;
