import Ripple from './Ripple';
export type { RippleProps } from './Ripple';
export default Ripple;
