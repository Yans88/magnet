import Menu from './Menu';
export type { MenuProps } from './Menu';
export default Menu;
