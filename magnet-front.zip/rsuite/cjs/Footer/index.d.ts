import Footer from './Footer';
export type { FooterProps } from './Footer';
export default Footer;
