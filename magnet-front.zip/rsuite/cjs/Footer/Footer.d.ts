import { ComponentProps } from '../utils/createComponent';
export declare type FooterProps = ComponentProps;
declare const Footer: import("../@types/common").RsRefForwardingComponent<"div", ComponentProps>;
export default Footer;
