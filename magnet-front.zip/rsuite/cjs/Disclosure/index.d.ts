import Disclosure from './Disclosure';
export type { DisclosureProps } from './Disclosure';
export default Disclosure;
