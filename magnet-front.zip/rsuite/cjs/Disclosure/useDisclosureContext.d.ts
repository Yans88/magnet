import { DisclosureContextProps } from './DisclosureContext';
export default function useDisclosureContext(component: string): DisclosureContextProps;
