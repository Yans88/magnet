import Placeholder from './Placeholder';
export type { PlaceholderGraphProps } from './PlaceholderGraph';
export type { PlaceholderGridProps } from './PlaceholderGrid';
export type { PlaceholderParagraphProps } from './PlaceholderParagraph';
export default Placeholder;
