import Loader from './Loader';
export type { LoaderProps } from './Loader';
export default Loader;
