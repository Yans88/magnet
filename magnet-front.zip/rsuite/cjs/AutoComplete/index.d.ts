import AutoComplete from './AutoComplete';
export type { AutoCompleteProps } from './AutoComplete';
export default AutoComplete;
